package com.bridesandgrooms.event

interface OnItemClickListener {

    fun onItemClick(index: Int, countselected: ArrayList<Int>)
}