package com.bridesandgrooms.event

open class Task {
    var key: String = ""
    var name: String = ""
    var date: String = ""
    var category: String = ""
    var budget: String = ""
    var status: String = ""
    var eventid: String = ""
    var createdatetime: String = ""
    //At some point I will be adding the updatedatetime
}