package com.bridesandgrooms.event.Model

data class TableGuests(val table: String, val count: Int, val tableguestlist: ArrayList<Guest>)