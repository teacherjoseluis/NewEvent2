package com.bridesandgrooms.event.Model

open class Contact {
    var key: String = ""
    var name: String = ""
    var phone: String = ""
    var email: String = ""
    var createdatetime: String = ""
}
