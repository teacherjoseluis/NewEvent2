package com.bridesandgrooms.event

open class Contact {
    var key: String = ""
    var name: String = ""
    var phone: String = ""
    var email: String = ""
}
