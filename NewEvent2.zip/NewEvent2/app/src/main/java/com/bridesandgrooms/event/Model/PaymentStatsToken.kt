package com.bridesandgrooms.event.Model

class PaymentStatsToken(
    var paymentcompleted: Int = 0,
    var sumpayments: String = ""
)