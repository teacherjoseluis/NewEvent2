package com.bridesandgrooms.event.Model

class TaskStatsToken(
    var taskpending: Int = 0,
    var taskcompleted: Int = 0,
    var sumbudget: String = ""
)