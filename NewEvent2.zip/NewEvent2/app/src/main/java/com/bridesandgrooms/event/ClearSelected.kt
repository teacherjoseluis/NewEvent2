package com.bridesandgrooms.event

interface ClearSelected {
    fun onClearSelected():Boolean
}