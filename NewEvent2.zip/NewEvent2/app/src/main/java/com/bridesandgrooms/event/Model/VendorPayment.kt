package com.bridesandgrooms.event.Model


data class VendorPayment(val vendor: Vendor, val amountlist: ArrayList<Float>)