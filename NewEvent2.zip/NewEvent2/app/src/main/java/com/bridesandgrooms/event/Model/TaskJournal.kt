package com.bridesandgrooms.event.Model

import java.util.*

data class TaskJournal(val date: Date, val taskjournallist: ArrayList<Task>)